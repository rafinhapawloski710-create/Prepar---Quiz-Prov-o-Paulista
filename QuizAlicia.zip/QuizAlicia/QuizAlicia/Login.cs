﻿/*
 * Created by SharpDevelop.
 * User: rafin
 * Date: 08/10/2025
 * Time: 10:35
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace QuizAlicia
{
	/// <summary>
	/// Description of Login.
	/// </summary>
	public partial class Login : Form
	{
		public Login()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void BtnCadastroClick(object sender, EventArgs e)
		{
			Cadastro telaCadastro = new Cadastro();
			telaCadastro.Show();
			this.Hide();
		}
		
		
		string arquivo = "usuarios.txt";
		void BtnEnviarClick(object sender, EventArgs e)
		{
			string usuario = txtNome.Text.Trim();
      		string senha = txtSenha.Text.Trim();

      if (!File.Exists(arquivo)){
        MessageBox.Show("Nenhum usuário cadastrado.");
      }

      bool encontrado = false;
      foreach (string linha in File.ReadAllLines(arquivo)){
        string[] dados = linha.Split(';');
        if (dados[0] == usuario && dados[1] == senha){
          MessageBox.Show("Login realizado com sucesso");
          encontrado = true;
        }
      }

      if (encontrado == false){
        MessageBox.Show("Usuário ou senha incorretos.");
        txtNome.Clear();
        txtSenha.Clear();
        return;
      }
			
			Inicio telaInicio = new Inicio();
			telaInicio.Show();
			this.Hide();
		}
		
		void BtnReiniciarClick(object sender, EventArgs e)
		{
			txtNome.Text = "";
			txtSenha.Text = "";
		}
		
		void Panel1Paint(object sender, PaintEventArgs e)
		{
			
		}
	}
}
