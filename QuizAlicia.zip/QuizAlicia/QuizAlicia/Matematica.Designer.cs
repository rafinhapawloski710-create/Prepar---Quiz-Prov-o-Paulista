﻿/*
 * Created by SharpDevelop.
 * User: rafin
 * Date: 08/10/2025
 * Time: 10:30
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace QuizAlicia
{
	partial class Matematica
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnVoltar = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.lblMatematica = new System.Windows.Forms.Label();
			this.pnlPergunta = new System.Windows.Forms.Panel();
			this.btnD = new System.Windows.Forms.Button();
			this.btnC = new System.Windows.Forms.Button();
			this.btnB = new System.Windows.Forms.Button();
			this.btnA = new System.Windows.Forms.Button();
			this.lblQD = new System.Windows.Forms.Label();
			this.lblQC = new System.Windows.Forms.Label();
			this.lblQB = new System.Windows.Forms.Label();
			this.lblQA = new System.Windows.Forms.Label();
			this.lblTitulo = new System.Windows.Forms.Label();
			this.btnResetar = new System.Windows.Forms.Button();
			this.btn5 = new System.Windows.Forms.Button();
			this.btn4 = new System.Windows.Forms.Button();
			this.btn1 = new System.Windows.Forms.Button();
			this.btn3 = new System.Windows.Forms.Button();
			this.btn2 = new System.Windows.Forms.Button();
			this.btnVerP = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			this.pnlPergunta.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnVoltar
			// 
			this.btnVoltar.BackColor = System.Drawing.Color.DarkSeaGreen;
			this.btnVoltar.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnVoltar.Location = new System.Drawing.Point(82, 386);
			this.btnVoltar.Name = "btnVoltar";
			this.btnVoltar.Size = new System.Drawing.Size(78, 35);
			this.btnVoltar.TabIndex = 6;
			this.btnVoltar.Text = "<----";
			this.btnVoltar.UseVisualStyleBackColor = false;
			this.btnVoltar.Click += new System.EventHandler(this.BtnVoltarClick);
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.PaleGreen;
			this.panel1.Controls.Add(this.lblMatematica);
			this.panel1.Controls.Add(this.pnlPergunta);
			this.panel1.Controls.Add(this.btnResetar);
			this.panel1.Controls.Add(this.btn5);
			this.panel1.Controls.Add(this.btn4);
			this.panel1.Controls.Add(this.btn1);
			this.panel1.Controls.Add(this.btn3);
			this.panel1.Controls.Add(this.btn2);
			this.panel1.Location = new System.Drawing.Point(39, 34);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(415, 341);
			this.panel1.TabIndex = 8;
			this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel1Paint);
			// 
			// lblMatematica
			// 
			this.lblMatematica.Font = new System.Drawing.Font("Script MT Bold", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblMatematica.Location = new System.Drawing.Point(105, 18);
			this.lblMatematica.Name = "lblMatematica";
			this.lblMatematica.Size = new System.Drawing.Size(206, 42);
			this.lblMatematica.TabIndex = 15;
			this.lblMatematica.Text = "Matemática";
			// 
			// pnlPergunta
			// 
			this.pnlPergunta.BackColor = System.Drawing.Color.White;
			this.pnlPergunta.Controls.Add(this.btnD);
			this.pnlPergunta.Controls.Add(this.btnC);
			this.pnlPergunta.Controls.Add(this.btnB);
			this.pnlPergunta.Controls.Add(this.btnA);
			this.pnlPergunta.Controls.Add(this.lblQD);
			this.pnlPergunta.Controls.Add(this.lblQC);
			this.pnlPergunta.Controls.Add(this.lblQB);
			this.pnlPergunta.Controls.Add(this.lblQA);
			this.pnlPergunta.Controls.Add(this.lblTitulo);
			this.pnlPergunta.Location = new System.Drawing.Point(38, 74);
			this.pnlPergunta.Name = "pnlPergunta";
			this.pnlPergunta.Size = new System.Drawing.Size(330, 180);
			this.pnlPergunta.TabIndex = 14;
			// 
			// btnD
			// 
			this.btnD.Location = new System.Drawing.Point(6, 143);
			this.btnD.Name = "btnD";
			this.btnD.Size = new System.Drawing.Size(25, 27);
			this.btnD.TabIndex = 17;
			this.btnD.Text = "D";
			this.btnD.UseVisualStyleBackColor = true;
			this.btnD.Click += new System.EventHandler(this.BtnDClick);
			// 
			// btnC
			// 
			this.btnC.Location = new System.Drawing.Point(6, 111);
			this.btnC.Name = "btnC";
			this.btnC.Size = new System.Drawing.Size(25, 27);
			this.btnC.TabIndex = 16;
			this.btnC.Text = "C";
			this.btnC.UseVisualStyleBackColor = true;
			this.btnC.Click += new System.EventHandler(this.BtnCClick);
			// 
			// btnB
			// 
			this.btnB.Location = new System.Drawing.Point(6, 79);
			this.btnB.Name = "btnB";
			this.btnB.Size = new System.Drawing.Size(25, 27);
			this.btnB.TabIndex = 15;
			this.btnB.Text = "B";
			this.btnB.UseVisualStyleBackColor = true;
			this.btnB.Click += new System.EventHandler(this.BtnBClick);
			// 
			// btnA
			// 
			this.btnA.Location = new System.Drawing.Point(6, 46);
			this.btnA.Name = "btnA";
			this.btnA.Size = new System.Drawing.Size(25, 27);
			this.btnA.TabIndex = 14;
			this.btnA.Text = "A";
			this.btnA.UseVisualStyleBackColor = true;
			this.btnA.Click += new System.EventHandler(this.BtnAClick);
			// 
			// lblQD
			// 
			this.lblQD.Location = new System.Drawing.Point(37, 148);
			this.lblQD.Name = "lblQD";
			this.lblQD.Size = new System.Drawing.Size(275, 23);
			this.lblQD.TabIndex = 8;
			this.lblQD.Text = "?";
			// 
			// lblQC
			// 
			this.lblQC.Location = new System.Drawing.Point(37, 116);
			this.lblQC.Name = "lblQC";
			this.lblQC.Size = new System.Drawing.Size(275, 23);
			this.lblQC.TabIndex = 7;
			this.lblQC.Text = "?";
			// 
			// lblQB
			// 
			this.lblQB.Location = new System.Drawing.Point(37, 84);
			this.lblQB.Name = "lblQB";
			this.lblQB.Size = new System.Drawing.Size(275, 23);
			this.lblQB.TabIndex = 6;
			this.lblQB.Text = "?";
			// 
			// lblQA
			// 
			this.lblQA.Location = new System.Drawing.Point(37, 51);
			this.lblQA.Name = "lblQA";
			this.lblQA.Size = new System.Drawing.Size(290, 23);
			this.lblQA.TabIndex = 5;
			this.lblQA.Text = "?";
			// 
			// lblTitulo
			// 
			this.lblTitulo.Location = new System.Drawing.Point(3, 10);
			this.lblTitulo.Name = "lblTitulo";
			this.lblTitulo.Size = new System.Drawing.Size(51, 180);
			this.lblTitulo.TabIndex = 0;
			this.lblTitulo.Text = "?";
			// 
			// btnResetar
			// 
			this.btnResetar.BackColor = System.Drawing.Color.DarkSeaGreen;
			this.btnResetar.Location = new System.Drawing.Point(287, 279);
			this.btnResetar.Name = "btnResetar";
			this.btnResetar.Size = new System.Drawing.Size(88, 23);
			this.btnResetar.TabIndex = 13;
			this.btnResetar.Text = "Resetar";
			this.btnResetar.UseVisualStyleBackColor = false;
			this.btnResetar.Click += new System.EventHandler(this.BtnResetarClick);
			// 
			// btn5
			// 
			this.btn5.Location = new System.Drawing.Point(230, 279);
			this.btn5.Name = "btn5";
			this.btn5.Size = new System.Drawing.Size(31, 23);
			this.btn5.TabIndex = 12;
			this.btn5.Text = "5";
			this.btn5.UseVisualStyleBackColor = true;
			this.btn5.Click += new System.EventHandler(this.Btn5Click);
			// 
			// btn4
			// 
			this.btn4.Location = new System.Drawing.Point(181, 279);
			this.btn4.Name = "btn4";
			this.btn4.Size = new System.Drawing.Size(31, 23);
			this.btn4.TabIndex = 11;
			this.btn4.Text = "4";
			this.btn4.UseVisualStyleBackColor = true;
			this.btn4.Click += new System.EventHandler(this.Btn4Click);
			// 
			// btn1
			// 
			this.btn1.Location = new System.Drawing.Point(40, 279);
			this.btn1.Name = "btn1";
			this.btn1.Size = new System.Drawing.Size(31, 23);
			this.btn1.TabIndex = 8;
			this.btn1.Text = "1";
			this.btn1.UseVisualStyleBackColor = true;
			this.btn1.Click += new System.EventHandler(this.Btn1Click);
			// 
			// btn3
			// 
			this.btn3.Location = new System.Drawing.Point(134, 279);
			this.btn3.Name = "btn3";
			this.btn3.Size = new System.Drawing.Size(31, 23);
			this.btn3.TabIndex = 10;
			this.btn3.Text = "3";
			this.btn3.UseVisualStyleBackColor = true;
			this.btn3.Click += new System.EventHandler(this.Btn3Click);
			// 
			// btn2
			// 
			this.btn2.Location = new System.Drawing.Point(86, 279);
			this.btn2.Name = "btn2";
			this.btn2.Size = new System.Drawing.Size(31, 23);
			this.btn2.TabIndex = 9;
			this.btn2.Text = "2";
			this.btn2.UseVisualStyleBackColor = true;
			this.btn2.Click += new System.EventHandler(this.Btn2Click);
			// 
			// btnVerP
			// 
			this.btnVerP.BackColor = System.Drawing.Color.DarkSeaGreen;
			this.btnVerP.Enabled = false;
			this.btnVerP.Location = new System.Drawing.Point(326, 386);
			this.btnVerP.Name = "btnVerP";
			this.btnVerP.Size = new System.Drawing.Size(120, 35);
			this.btnVerP.TabIndex = 12;
			this.btnVerP.Text = "Ver Pontuação";
			this.btnVerP.UseVisualStyleBackColor = false;
			this.btnVerP.Click += new System.EventHandler(this.BtnVerPClick);
			// 
			// Matematica
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(486, 433);
			this.Controls.Add(this.btnVerP);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.btnVoltar);
			this.Name = "Matematica";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Matematica";
			this.panel1.ResumeLayout(false);
			this.pnlPergunta.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Button btnVerP;
		private System.Windows.Forms.Button btnD;
		private System.Windows.Forms.Button btnC;
		private System.Windows.Forms.Button btnB;
		private System.Windows.Forms.Button btnA;
		private System.Windows.Forms.Button btn2;
		private System.Windows.Forms.Button btn3;
		private System.Windows.Forms.Button btn1;
		private System.Windows.Forms.Button btn4;
		private System.Windows.Forms.Button btn5;
		private System.Windows.Forms.Button btnResetar;
		private System.Windows.Forms.Label lblTitulo;
		private System.Windows.Forms.Label lblQA;
		private System.Windows.Forms.Label lblQB;
		private System.Windows.Forms.Label lblQC;
		private System.Windows.Forms.Label lblQD;
		private System.Windows.Forms.Panel pnlPergunta;
		private System.Windows.Forms.Label lblMatematica;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button btnVoltar;
	}
}
