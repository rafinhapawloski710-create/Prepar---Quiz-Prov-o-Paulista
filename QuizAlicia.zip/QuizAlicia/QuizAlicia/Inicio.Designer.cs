﻿/*
 * Created by SharpDevelop.
 * User: rafin
 * Date: 06/10/2025
 * Time: 11:42
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace QuizAlicia
{
	partial class Inicio
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inicio));
			this.lblPreparo = new System.Windows.Forms.Label();
			this.lblProvão = new System.Windows.Forms.Label();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.btnCréditos = new System.Windows.Forms.Button();
			this.btnPlacar = new System.Windows.Forms.Button();
			this.btnJogar = new System.Windows.Forms.Button();
			this.btnSair = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// lblPreparo
			// 
			this.lblPreparo.Font = new System.Drawing.Font("Cooper Black", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPreparo.ForeColor = System.Drawing.Color.Chartreuse;
			this.lblPreparo.Location = new System.Drawing.Point(231, 29);
			this.lblPreparo.Name = "lblPreparo";
			this.lblPreparo.Size = new System.Drawing.Size(178, 44);
			this.lblPreparo.TabIndex = 0;
			this.lblPreparo.Text = "Preparô";
			this.lblPreparo.Click += new System.EventHandler(this.LblPreparoClick);
			// 
			// lblProvão
			// 
			this.lblProvão.Font = new System.Drawing.Font("Cooper Black", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblProvão.ForeColor = System.Drawing.Color.Chartreuse;
			this.lblProvão.Location = new System.Drawing.Point(127, 82);
			this.lblProvão.Name = "lblProvão";
			this.lblProvão.Size = new System.Drawing.Size(405, 45);
			this.lblProvão.TabIndex = 1;
			this.lblProvão.Text = "Quiz Provão Paulista";
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(139, 147);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(311, 262);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 2;
			this.pictureBox1.TabStop = false;
			// 
			// btnCréditos
			// 
			this.btnCréditos.Location = new System.Drawing.Point(517, 272);
			this.btnCréditos.Name = "btnCréditos";
			this.btnCréditos.Size = new System.Drawing.Size(92, 32);
			this.btnCréditos.TabIndex = 3;
			this.btnCréditos.Text = "Créditos";
			this.btnCréditos.UseVisualStyleBackColor = true;
			this.btnCréditos.Click += new System.EventHandler(this.BtnCréditosClick);
			// 
			// btnPlacar
			// 
			this.btnPlacar.Location = new System.Drawing.Point(517, 326);
			this.btnPlacar.Name = "btnPlacar";
			this.btnPlacar.Size = new System.Drawing.Size(92, 31);
			this.btnPlacar.TabIndex = 4;
			this.btnPlacar.Text = "Placar";
			this.btnPlacar.UseVisualStyleBackColor = true;
			this.btnPlacar.Click += new System.EventHandler(this.BtnPlacarClick);
			// 
			// btnJogar
			// 
			this.btnJogar.BackColor = System.Drawing.Color.LimeGreen;
			this.btnJogar.ForeColor = System.Drawing.Color.Black;
			this.btnJogar.Location = new System.Drawing.Point(517, 377);
			this.btnJogar.Name = "btnJogar";
			this.btnJogar.Size = new System.Drawing.Size(92, 32);
			this.btnJogar.TabIndex = 5;
			this.btnJogar.Text = "Jogar";
			this.btnJogar.UseVisualStyleBackColor = false;
			this.btnJogar.Click += new System.EventHandler(this.BtnJogarClick);
			// 
			// btnSair
			// 
			this.btnSair.Location = new System.Drawing.Point(517, 425);
			this.btnSair.Name = "btnSair";
			this.btnSair.Size = new System.Drawing.Size(92, 26);
			this.btnSair.TabIndex = 6;
			this.btnSair.Text = "Sair";
			this.btnSair.UseVisualStyleBackColor = true;
			this.btnSair.Click += new System.EventHandler(this.BtnSairClick);
			// 
			// Inicio
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(637, 479);
			this.Controls.Add(this.btnSair);
			this.Controls.Add(this.btnJogar);
			this.Controls.Add(this.btnPlacar);
			this.Controls.Add(this.btnCréditos);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.lblProvão);
			this.Controls.Add(this.lblPreparo);
			this.Name = "Inicio";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Inicio";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Button btnSair;
		private System.Windows.Forms.Button btnJogar;
		private System.Windows.Forms.Button btnPlacar;
		private System.Windows.Forms.Button btnCréditos;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label lblProvão;
		private System.Windows.Forms.Label lblPreparo;
	}
}
