﻿/*
 * Created by SharpDevelop.
 * User: rafin
 * Date: 08/10/2025
 * Time: 10:29
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace QuizAlicia
{
	/// <summary>
	/// Description of Historia.
	/// </summary>
	public partial class Historia : Form
	{
		public Historia()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		string alternativaCorreta = "X";
		int pontos = 0;
		
		void BtnVoltarClick(object sender, EventArgs e)
		{
			Seleção telaSelecao = new Seleção();
			telaSelecao.Show();
			this.Hide();
		}
		
		void Btn1Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "O Iluminismo defendia principalmente:";
			lblQA.Text = "A fé acima da razão";
			lblQB.Text = " A razão e a liberdade de pensamento";
			lblQC.Text = "O poder absoluto do rei";
			lblQD.Text = "O retorno ao feudalismo";
			alternativaCorreta = "B";
			
			btn1.Enabled = false;
			pnlPergunta.Enabled = true;
			btn2.Enabled = true;
		}
		
		void Btn2Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "A Revolução Francesa começou em:";
			lblQA.Text = "1492";
			lblQB.Text = "1776";
			lblQC.Text = "1789";
			lblQD.Text = "1808";
			alternativaCorreta = "C";
			
			btn2.Enabled = false;
			pnlPergunta.Enabled = true;
			btn3.Enabled = true;
		}
		
		void Btn3Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "A escravidão africana foi usada no Brasil principalmente para:";
			lblQA.Text = " Ajudar na corte portuguesa";
			lblQB.Text = "Trabalhar nas lavouras de cana e café";
			lblQC.Text = "Construir palácios reais";
			lblQD.Text = "Produzir ouro";
			alternativaCorreta = "B";
			
			btn3.Enabled = false;
			pnlPergunta.Enabled = true;
			btn4.Enabled = true;			
		}
		
		void Btn4Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "O governo de Getúlio Vargas ficou conhecido pelo:";
			lblQA.Text = "Liberalismo econômico";
			lblQB.Text = "Estado Novo";
			lblQC.Text = "Colonialismo";
			lblQD.Text = "Absolutismo";
			alternativaCorreta = "B";
			
			btn5.Enabled = false;
			pnlPergunta.Enabled = true;
			btn5.Enabled = true;
		}
		
		void Btn5Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "A Primeira Guerra Mundial começou por causa:";
			lblQA.Text = " Da morte do arquiduque Francisco Ferdinando";
			lblQB.Text = "Da queda do muro de Berlim";
			lblQC.Text = "Da crise de 1929";
			lblQD.Text = "Da independência dos EUA";
			alternativaCorreta = "A";
			
			btn5.Enabled = false;
			pnlPergunta.Enabled = true;
			btnVerP.Enabled = true;
		}
		
		
		void BtnResetarClick(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = false;
			btn1.Enabled = true;
			btn2.Enabled = false;
			btn3.Enabled = false;
			btn4.Enabled = false;
			btn5.Enabled = false;
			lblTitulo.Text = "?";
			lblQA.Text = "?";
			lblQB.Text = "?";
			lblQC.Text = "?";
			lblQD.Text = "?";
			
			pontos = 0;
		}
		
		void BtnAClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "B"){
				MessageBox.Show("Você Acertou!");
				pontos++;
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void BtnBClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "D"){
				MessageBox.Show("Você Acertou!");
				pontos++;
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void BtnCClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "A"){
				MessageBox.Show("Você Acertou!");
				pontos++;
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void BtnDClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "C"){
				MessageBox.Show("Você Acertou!");
				pontos++;
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void LblTituloClick(object sender, EventArgs e)
		{
			
		}
		
		void HistoriaLoad(object sender, EventArgs e)
		{
			
		}
		
		void BtnVerPClick(object sender, EventArgs e)
		{
			MessageBox.Show("Parabéns! Você completou o quiz. " + "Pontuação: " + pontos + "/5");
		}
	}
}
