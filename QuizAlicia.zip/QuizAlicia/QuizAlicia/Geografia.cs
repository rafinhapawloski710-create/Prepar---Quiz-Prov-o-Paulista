﻿/*
 * Created by SharpDevelop.
 * User: rafin
 * Date: 08/10/2025
 * Time: 10:29
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace QuizAlicia
{
	/// <summary>
	/// Description of Geografia.
	/// </summary>
	public partial class Geografia : Form
	{
		public Geografia()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		string alternativaCorreta = "X";
		int pontos = 0;
		
		void BtnVoltarClick(object sender, EventArgs e)
		{
			Seleção telaSelecao = new Seleção();
			telaSelecao.Show();
			this.Hide();
		}
		
		void BtnResetarClick(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = false;
			btn1.Enabled = true;
			btn2.Enabled = false;
			btn3.Enabled = false;
			btn4.Enabled = false;
			btn5.Enabled = false;
			lblTitulo.Text = "?";
			lblQA.Text = "?";
			lblQB.Text = "?";
			lblQC.Text = "?";
			lblQD.Text = "?";
			
			pontos = 0;
		}
		
		void BtnAClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "A"){
				MessageBox.Show("Você Acertou!");
				pontos++;
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void BtnBClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "A"){
				MessageBox.Show("Você Acertou!");
				pontos++;
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void BtnCClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "A"){
				MessageBox.Show("Você Acertou!");
				pontos++;
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void BtnDClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "A"){
				MessageBox.Show("Você Acertou!");
				pontos++;
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void Btn1Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "O que é latitude?";
			lblQA.Text = "Distância em relação ao Equador";
			lblQB.Text = "Distância em relação ao meridiano de Greenwich";
			lblQC.Text = "Altura do relevo";
			lblQD.Text = " Temperatura média";
			alternativaCorreta = "A";
			
			btn1.Enabled = false;
			pnlPergunta.Enabled = true;
			btn2.Enabled = true;
		}
		
		void Btn2Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "O desmatamento afeta principalmente:";
			lblQA.Text = "As geleiras";
			lblQB.Text = "A biodiversidade";
			lblQC.Text = "O clima do deserto";
			lblQD.Text = "O lençol freático";
			alternativaCorreta = "B";
			
			btn1.Enabled = false;
			pnlPergunta.Enabled = true;
			btn2.Enabled = true;
		}
		
		void Btn3Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "O Brasil é dividido em quantas regiões geográficas oficiais?";
			lblQA.Text = "4";
			lblQB.Text = "5";
			lblQC.Text = "6";
			lblQD.Text = "7";
			alternativaCorreta = "B";
			
			btn3 .Enabled = false;
			pnlPergunta.Enabled = true;
			btn4.Enabled = true;
		}
		
		void Btn4Click(object sender, EventArgs e)
		{
			
		pnlPergunta.Enabled = true;
			lblTitulo.Text = "O que é um aquífero?";
			lblQA.Text = "Um rio subterrâneo";
			lblQB.Text = "Um tipo de montanha";
			lblQC.Text = "Um vulcão extinto";
			lblQD.Text = "Um tipo de solo arenoso";
			alternativaCorreta = "A";
			
			btn4.Enabled = false;
			pnlPergunta.Enabled = true;
			btn5.Enabled = true;
		}
		
		void Btn5Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "Qual região do Brasil tem o maior número de estados?";
			lblQA.Text = "Norte";
			lblQB.Text = "Nordeste";
			lblQC.Text = "Sudeste";
			lblQD.Text = "Sul";
			alternativaCorreta = "B";
			
			btn5.Enabled = false;
			pnlPergunta.Enabled = true;
			btnVerP.Enabled = true;
		}
		
		void BtnVerPClick(object sender, EventArgs e)
		{
			MessageBox.Show("Parabéns! Você completou o quiz. " + "Pontuação: " + pontos + "/5");
		}
	}
}
