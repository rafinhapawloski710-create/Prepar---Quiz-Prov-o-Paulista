﻿/*
 * Created by SharpDevelop.
 * User: rafin
 * Date: 08/10/2025
 * Time: 08:54
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace QuizAlicia
{
	partial class Creditos
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblCreditos = new System.Windows.Forms.Label();
			this.lblDesenvolver = new System.Windows.Forms.Label();
			this.lblRafael = new System.Windows.Forms.Label();
			this.lblVitoria = new System.Windows.Forms.Label();
			this.btnVoltar = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblCreditos
			// 
			this.lblCreditos.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCreditos.Location = new System.Drawing.Point(169, 27);
			this.lblCreditos.Name = "lblCreditos";
			this.lblCreditos.Size = new System.Drawing.Size(143, 37);
			this.lblCreditos.TabIndex = 0;
			this.lblCreditos.Text = "Créditos";
			// 
			// lblDesenvolver
			// 
			this.lblDesenvolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblDesenvolver.Location = new System.Drawing.Point(127, 112);
			this.lblDesenvolver.Name = "lblDesenvolver";
			this.lblDesenvolver.Size = new System.Drawing.Size(265, 23);
			this.lblDesenvolver.TabIndex = 1;
			this.lblDesenvolver.Text = "Criado e Desenvolvido por:";
			// 
			// lblRafael
			// 
			this.lblRafael.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblRafael.Location = new System.Drawing.Point(141, 178);
			this.lblRafael.Name = "lblRafael";
			this.lblRafael.Size = new System.Drawing.Size(229, 23);
			this.lblRafael.TabIndex = 2;
			this.lblRafael.Text = "Rafael Pawloski de Brito";
			this.lblRafael.Click += new System.EventHandler(this.LblRafaelClick);
			// 
			// lblVitoria
			// 
			this.lblVitoria.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblVitoria.Location = new System.Drawing.Point(99, 219);
			this.lblVitoria.Name = "lblVitoria";
			this.lblVitoria.Size = new System.Drawing.Size(352, 23);
			this.lblVitoria.TabIndex = 3;
			this.lblVitoria.Text = "Vitória Jawhara Carvalho dos Santos";
			// 
			// btnVoltar
			// 
			this.btnVoltar.BackColor = System.Drawing.Color.Chartreuse;
			this.btnVoltar.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnVoltar.Location = new System.Drawing.Point(37, 385);
			this.btnVoltar.Name = "btnVoltar";
			this.btnVoltar.Size = new System.Drawing.Size(78, 35);
			this.btnVoltar.TabIndex = 4;
			this.btnVoltar.Text = "<----";
			this.btnVoltar.UseVisualStyleBackColor = false;
			this.btnVoltar.Click += new System.EventHandler(this.BtnVoltarClick);
			// 
			// Creditos
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(505, 458);
			this.Controls.Add(this.btnVoltar);
			this.Controls.Add(this.lblVitoria);
			this.Controls.Add(this.lblRafael);
			this.Controls.Add(this.lblDesenvolver);
			this.Controls.Add(this.lblCreditos);
			this.Name = "Creditos";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Creditos";
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Button btnVoltar;
		private System.Windows.Forms.Label lblVitoria;
		private System.Windows.Forms.Label lblRafael;
		private System.Windows.Forms.Label lblDesenvolver;
		private System.Windows.Forms.Label lblCreditos;
	}
}
