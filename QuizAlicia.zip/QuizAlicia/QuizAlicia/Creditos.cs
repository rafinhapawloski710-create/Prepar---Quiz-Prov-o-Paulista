﻿/*
 * Created by SharpDevelop.
 * User: rafin
 * Date: 08/10/2025
 * Time: 08:54
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace QuizAlicia
{
	/// <summary>
	/// Description of Creditos.
	/// </summary>
	public partial class Creditos : Form
	{
		public Creditos()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void BtnVoltarClick(object sender, EventArgs e)
		{
			Inicio telaInicio = new Inicio();
			telaInicio.Show();
			this.Hide();
		}
		
		void LblRafaelClick(object sender, EventArgs e)
		{
			
		}
	}
}
