﻿/*
 * Created by SharpDevelop.
 * User: rafin
 * Date: 08/10/2025
 * Time: 10:30
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace QuizAlicia
{
	/// <summary>
	/// Description of Geral.
	/// </summary>
	public partial class Geral : Form
	{
		public Geral()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		
		string alternativaCorreta = "X";
		int pontos = 0;
		
		void BtnVoltarClick(object sender, EventArgs e)
		{
			Seleção telaSelecao = new Seleção();
			telaSelecao.Show();
			this.Hide();
		}
		
		void BtnResetarClick(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = false;
			btn1.Enabled = true;
			btn2.Enabled = false;
			btn3.Enabled = false;
			btn4.Enabled = false;
			btn5.Enabled = false;
			lblTitulo.Text = "?";
			lblQA.Text = "?";
			lblQB.Text = "?";
			lblQC.Text = "?";
			lblQD.Text = "?";
			
			pontos = 0;
			
		}
		
		void BtnAClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "A"){
				MessageBox.Show("Você Acertou!");
				pontos++;
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void BtnBClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "B"){
				MessageBox.Show("Você Acertou!");
				pontos++;
				
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void BtnCClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "C"){
				MessageBox.Show("Você Acertou!");
				pontos++;
				
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void BtnDClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "D"){
				MessageBox.Show("Você Acertou!");
				pontos++;
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void Panel1Paint(object sender, PaintEventArgs e)
		{
			
		}
		
		void Btn2Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "A forma correta do plural de “cidadão” é:";
			lblQA.Text = "Cidadões";
			lblQB.Text = "Cidadãos";
			lblQC.Text = "Cidades";
			lblQD.Text = "Cidadães";
			alternativaCorreta = "B";
			
			btn2.Enabled = false;
			pnlPergunta.Enabled = true;
			btn3.Enabled = true;
			btnA.Enabled = true;
			btnB.Enabled = true;
			btnC.Enabled = true;
			btnD.Enabled = true;
		}
		
		void Btn1Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "A palavra “difícil” é um(a):";
			lblQA.Text = "Substantivo";
			lblQB.Text = "Adjetivo";
			lblQC.Text = "Advérbio";
			lblQD.Text = "Verbo";
			alternativaCorreta = "B";
			
			btn1.Enabled = false;
			pnlPergunta.Enabled = true;
			btn2.Enabled = true;
			btnA.Enabled = true;
			btnB.Enabled = true;
			btnC.Enabled = true;
			btnD.Enabled = true;
		}
		
		void Btn3Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "O regime militar no Brasil começou em:";
			lblQA.Text = "1964";
			lblQB.Text = "1950";
			lblQC.Text = "1978";
			lblQD.Text = "1988";
			alternativaCorreta = "A";
			
			btn3.Enabled = false;
			pnlPergunta.Enabled = true;
			btn4.Enabled = true;
			btnA.Enabled = true;
			btnB.Enabled = true;
			btnC.Enabled = true;
			btnD.Enabled = true;
		}
		
		void Btn4Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "O que foi a Guerra Fria?";
			lblQA.Text = "Conflito direto entre EUA e URSS";
			lblQB.Text = "Disputa política e ideológica entre EUA e URSS";
			lblQC.Text = "Guerra entre países da América do Sul";
			lblQD.Text = " Revolta dos trabalhadores";
			alternativaCorreta = "B";
			
			btn4.Enabled = false;
			pnlPergunta.Enabled = true;
			btn5.Enabled = true;
			btnA.Enabled = true;
			btnB.Enabled = true;
			btnC.Enabled = true;
			btnD.Enabled = true;
		}
		
		void Btn5Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "O que é globalização?";
			lblQA.Text = "Isolamento entre países";
			lblQB.Text = "Interligação econômica e cultural mundial";
			lblQC.Text = "Controle estatal de empresas";
			lblQD.Text = "Um tipo de transporte";
			alternativaCorreta = "B";
			
			btn5.Enabled = false;
			pnlPergunta.Enabled = true;
			btn6.Enabled = true;
			btnA.Enabled = true;
			btnB.Enabled = true;
			btnC.Enabled = true;
			btnD.Enabled = true;
		}
		
		void Btn6Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "A principal causa do aquecimento global é:";
			lblQA.Text = "Poluição sonora";
			lblQB.Text = "Emissão de gases do efeito estufa";
			lblQC.Text = "Desmatamento apenas";
			lblQD.Text = "O uso de energia solar";
			alternativaCorreta = "B";
			
			btn6.Enabled = false;
			pnlPergunta.Enabled = true;
			btn7.Enabled = true;
			btnA.Enabled = true;
			btnB.Enabled = true;
			btnC.Enabled = true;
			btnD.Enabled = true;
		}
		
		void Btn7Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "Se um produto custa R$ 100 e tem 20% de desconto, ele passa a custar:";
			lblQA.Text = "R$ 80";
			lblQB.Text = "R$ 90";
			lblQC.Text = "R$ 70";
			lblQD.Text = "R$ 75";
			alternativaCorreta = "A";
			
			btn7.Enabled = false;
			pnlPergunta.Enabled = true;
			btn8.Enabled = true;
			btnA.Enabled = true;
			btnB.Enabled = true;
			btnC.Enabled = true;
			btnD.Enabled = true;
		}
		
		void Btn8Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "O gráfico de uma função do 1º grau é uma:";
			lblQA.Text = "Parabola";
			lblQB.Text = "Reta";
			lblQC.Text = "Curva fechada";
			lblQD.Text = "Elipse";
			alternativaCorreta = "B";
			
			btn8.Enabled = false;
			pnlPergunta.Enabled = true;
			btn9.Enabled = true;
			btnA.Enabled = true;
			btnB.Enabled = true;
			btnC.Enabled = true;
			btnD.Enabled = true;
		}
		
		void Btn9Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "Qual elemento químico é essencial na respiração celular?";
			lblQA.Text = "Carbono";
			lblQB.Text = "Oxigênio";
			lblQC.Text = "Nitrogênio";
			lblQD.Text = "Enxofre";
			alternativaCorreta = "B";
			
			btn9.Enabled = false;
			pnlPergunta.Enabled = true;
			btn10.Enabled = true;
			btnA.Enabled = true;
			btnB.Enabled = true;
			btnC.Enabled = true;
			btnD.Enabled = true;
		}
		
		void Btn10Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "Qual é o símbolo químico do ferro?";
			lblQA.Text = "F";
			lblQB.Text = "Fe";
			lblQC.Text = "Ir";
			lblQD.Text = "I";
			alternativaCorreta = "B";
			
			btn10.Enabled = false;
			pnlPergunta.Enabled = true;
			btn11.Enabled = true;
			btnA.Enabled = true;
			btnB.Enabled = true;
			btnC.Enabled = true;
			btnD.Enabled = true;
		}
		
		void Btn11Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "A corrente elétrica é o fluxo de:";
			lblQA.Text = "Átomos";
			lblQB.Text = "Elétrons";
			lblQC.Text = "Nêutrons";
			lblQD.Text = "Íons";
			alternativaCorreta = "B";
			
			btn11.Enabled = false;
			pnlPergunta.Enabled = true;
			btn12.Enabled = true;
			btnA.Enabled = true;
			btnB.Enabled = true;
			btnC.Enabled = true;
			btnD.Enabled = true;
		}
		
		void Btn12Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "O som não se propaga em:";
			lblQA.Text = "Ar";
			lblQB.Text = "Água";
			lblQC.Text = "Vácuo";
			lblQD.Text = "Metal";
			alternativaCorreta = "C";
			
			btn12.Enabled = false;
			btnVerP.Enabled = true;
			btnA.Enabled = true;
			btnB.Enabled = true;
			btnC.Enabled = true;
			btnD.Enabled = true;
		}
		
		void Button1Click(object sender, EventArgs e)
		{
			
			
			Parabens telaParab = new Parabens(pontos);
			telaParab.Show();
			this.Hide();
		}
	}
}
