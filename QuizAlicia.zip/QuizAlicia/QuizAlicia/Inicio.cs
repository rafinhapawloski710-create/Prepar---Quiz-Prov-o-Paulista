﻿/*
 * Created by SharpDevelop.
 * User: rafin
 * Date: 06/10/2025
 * Time: 11:42
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace QuizAlicia
{
	/// <summary>
	/// Description of Inicio.
	/// </summary>
	public partial class Inicio : Form
	{
		public Inicio()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void LblPreparoClick(object sender, EventArgs e)
		{
			
		}
		
		void BtnCréditosClick(object sender, EventArgs e)
		{
			Creditos telaCreditos = new Creditos();
			telaCreditos.Show();
			this.Hide();
		}
		
		void BtnSairClick(object sender, EventArgs e)
		{
			Application.Exit();
		}
		
		void BtnPlacarClick(object sender, EventArgs e)
		{
			Placar telaPlacar = new Placar();
			telaPlacar.Show();
			this.Hide();
		}
		
		void BtnJogarClick(object sender, EventArgs e)
		{
			Seleção telaSelecao = new Seleção();
			telaSelecao.Show();
			this.Hide();
		}
	}
}
