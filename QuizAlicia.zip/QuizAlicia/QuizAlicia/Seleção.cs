﻿/*
 * Created by SharpDevelop.
 * User: rafin
 * Date: 08/10/2025
 * Time: 09:16
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace QuizAlicia
{
	/// <summary>
	/// Description of Seleção.
	/// </summary>
	public partial class Seleção : Form
	{
		public Seleção()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void BtnVoltarClick(object sender, EventArgs e)
		{
			Inicio telaInicio = new Inicio();
			telaInicio.Show();
			this.Hide();
		}
		
		void Button4Click(object sender, EventArgs e)
		{
			Quimica telaQuimica = new Quimica();
			telaQuimica.Show();
			this.Hide();
		}
		
		void Button1Click(object sender, EventArgs e)
		{
			Portugues telaPortugues = new Portugues();
			telaPortugues.Show();
			this.Hide();
		}
		
		void Button2Click(object sender, EventArgs e)
		{
			Historia telaHistoria = new Historia();
			telaHistoria.Show();
			this.Hide();
		}
		
		void Button3Click(object sender, EventArgs e)
		{
			Geografia telaGeografia = new Geografia();
			telaGeografia.Show();
			this.Hide();
		}
		
		void Button5Click(object sender, EventArgs e)
		{
			Fisica telaFisica = new Fisica();
			telaFisica.Show();
			this.Hide();
		}
		
		void Button6Click(object sender, EventArgs e)
		{
			Matematica telaMatematica = new Matematica();
			telaMatematica.Show();
			this.Show();
		}
		
		void Button7Click(object sender, EventArgs e)
		{
			Geral telaGeral = new Geral();
			telaGeral.Show();
			this.Hide();
		}
		
		void LblHumanasClick(object sender, EventArgs e)
		{
			
		}
		
		void LblSeleçãoClick(object sender, EventArgs e)
		{
			
		}
	}
}
