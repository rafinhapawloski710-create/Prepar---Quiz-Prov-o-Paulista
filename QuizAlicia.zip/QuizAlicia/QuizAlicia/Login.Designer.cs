﻿/*
 * Created by SharpDevelop.
 * User: rafin
 * Date: 08/10/2025
 * Time: 10:35
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace QuizAlicia
{
	partial class Login
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
			this.panel1 = new System.Windows.Forms.Panel();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.btnCadastro = new System.Windows.Forms.Button();
			this.btnReiniciar = new System.Windows.Forms.Button();
			this.lblLogin = new System.Windows.Forms.Label();
			this.txtSenha = new System.Windows.Forms.TextBox();
			this.lblNaoPossui = new System.Windows.Forms.Label();
			this.txtNome = new System.Windows.Forms.TextBox();
			this.lblNome = new System.Windows.Forms.Label();
			this.lblSenha = new System.Windows.Forms.Label();
			this.btnEnviar = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.White;
			this.panel1.Controls.Add(this.pictureBox1);
			this.panel1.Controls.Add(this.btnCadastro);
			this.panel1.Controls.Add(this.btnReiniciar);
			this.panel1.Controls.Add(this.lblLogin);
			this.panel1.Controls.Add(this.txtSenha);
			this.panel1.Controls.Add(this.lblNaoPossui);
			this.panel1.Controls.Add(this.txtNome);
			this.panel1.Controls.Add(this.lblNome);
			this.panel1.Controls.Add(this.lblSenha);
			this.panel1.Controls.Add(this.btnEnviar);
			this.panel1.Location = new System.Drawing.Point(28, 12);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(428, 409);
			this.panel1.TabIndex = 0;
			this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel1Paint);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(168, 16);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(81, 75);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 14;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.WaitOnLoad = true;
			// 
			// btnCadastro
			// 
			this.btnCadastro.ForeColor = System.Drawing.Color.DeepSkyBlue;
			this.btnCadastro.Location = new System.Drawing.Point(316, 353);
			this.btnCadastro.Name = "btnCadastro";
			this.btnCadastro.Size = new System.Drawing.Size(82, 27);
			this.btnCadastro.TabIndex = 7;
			this.btnCadastro.Text = "Cadastro";
			this.btnCadastro.UseVisualStyleBackColor = true;
			this.btnCadastro.Click += new System.EventHandler(this.BtnCadastroClick);
			// 
			// btnReiniciar
			// 
			this.btnReiniciar.Location = new System.Drawing.Point(103, 302);
			this.btnReiniciar.Name = "btnReiniciar";
			this.btnReiniciar.Size = new System.Drawing.Size(80, 27);
			this.btnReiniciar.TabIndex = 13;
			this.btnReiniciar.Text = "Limpar";
			this.btnReiniciar.UseVisualStyleBackColor = true;
			this.btnReiniciar.Click += new System.EventHandler(this.BtnReiniciarClick);
			// 
			// lblLogin
			// 
			this.lblLogin.Font = new System.Drawing.Font("Script MT Bold", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblLogin.Location = new System.Drawing.Point(154, 94);
			this.lblLogin.Name = "lblLogin";
			this.lblLogin.Size = new System.Drawing.Size(141, 53);
			this.lblLogin.TabIndex = 0;
			this.lblLogin.Text = "Login";
			// 
			// txtSenha
			// 
			this.txtSenha.Location = new System.Drawing.Point(103, 258);
			this.txtSenha.Name = "txtSenha";
			this.txtSenha.Size = new System.Drawing.Size(217, 22);
			this.txtSenha.TabIndex = 12;
			// 
			// lblNaoPossui
			// 
			this.lblNaoPossui.Location = new System.Drawing.Point(168, 358);
			this.lblNaoPossui.Name = "lblNaoPossui";
			this.lblNaoPossui.Size = new System.Drawing.Size(152, 23);
			this.lblNaoPossui.TabIndex = 6;
			this.lblNaoPossui.Text = "Não Possui Cadastro?";
			// 
			// txtNome
			// 
			this.txtNome.Location = new System.Drawing.Point(103, 184);
			this.txtNome.Name = "txtNome";
			this.txtNome.Size = new System.Drawing.Size(217, 22);
			this.txtNome.TabIndex = 11;
			// 
			// lblNome
			// 
			this.lblNome.Location = new System.Drawing.Point(103, 158);
			this.lblNome.Name = "lblNome";
			this.lblNome.Size = new System.Drawing.Size(130, 23);
			this.lblNome.TabIndex = 9;
			this.lblNome.Text = "Nome do usúario:\r\n";
			// 
			// lblSenha
			// 
			this.lblSenha.Location = new System.Drawing.Point(103, 232);
			this.lblSenha.Name = "lblSenha";
			this.lblSenha.Size = new System.Drawing.Size(100, 23);
			this.lblSenha.TabIndex = 10;
			this.lblSenha.Text = "Senha:";
			// 
			// btnEnviar
			// 
			this.btnEnviar.Location = new System.Drawing.Point(240, 302);
			this.btnEnviar.Name = "btnEnviar";
			this.btnEnviar.Size = new System.Drawing.Size(80, 27);
			this.btnEnviar.TabIndex = 8;
			this.btnEnviar.Text = "Entrar";
			this.btnEnviar.UseVisualStyleBackColor = true;
			this.btnEnviar.Click += new System.EventHandler(this.BtnEnviarClick);
			// 
			// Login
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.PaleGreen;
			this.ClientSize = new System.Drawing.Size(486, 433);
			this.Controls.Add(this.panel1);
			this.Name = "Login";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Login";
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button btnEnviar;
		private System.Windows.Forms.Label lblSenha;
		private System.Windows.Forms.Label lblNome;
		private System.Windows.Forms.TextBox txtNome;
		private System.Windows.Forms.TextBox txtSenha;
		private System.Windows.Forms.Button btnReiniciar;
		private System.Windows.Forms.Label lblNaoPossui;
		private System.Windows.Forms.Button btnCadastro;
		private System.Windows.Forms.Label lblLogin;
		private System.Windows.Forms.Panel panel1;
	}
}
