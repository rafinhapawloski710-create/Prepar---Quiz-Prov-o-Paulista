﻿/*
 * Created by SharpDevelop.
 * User: rafin
 * Date: 08/10/2025
 * Time: 09:09
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace QuizAlicia
{
	/// <summary>
	/// Description of Placar.
	/// </summary>
	public partial class Placar : Form
	{
		public Placar()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}

		
		void BtnVoltarClick(object sender, EventArgs e)
		{
			Inicio telaInicio = new Inicio();
			telaInicio.Show();
			this.Hide();
		}
		
		void PlacarLoad(object sender, EventArgs e)
		{
			try                                         
            {
                string caminhoArquivo = "pontuacoes.txt"; 

                if (!File.Exists(caminhoArquivo))        
                {
                    MessageBox.Show("Arquivo 'pontuacoes.txt' não encontrado!"); 
                    return;                              
                }

                string[] linhas = File.ReadAllLines(caminhoArquivo); 
                int qtd = linhas.Length;             

                string[] nomes = new string[qtd];    
                int[] pontos = new int[qtd];         
                int contador = 0;                    

              
                foreach (string linha in linhas)     
                {
                    string[] partes = linha.Split(','); 

                    if (partes.Length == 2)          
                    {
                        string nome = partes[0].Trim();  
                        int valor;                        

                        if (int.TryParse(partes[1].Trim(), out valor)) 
                        {
                            nomes[contador] = nome;       
                            pontos[contador] = valor;    
                            contador++;                  
                        }
                        
                    }
                    
                }

                
                for (int i = 0; i < contador - 1; i++)   
                {
                    for (int j = i + 1; j < contador; j++) 
                    {
                        if (pontos[j] > pontos[i])     
                        {
                            int tempPontos = pontos[i]; 
                            pontos[i] = pontos[j];      
                            pontos[j] = tempPontos;     

                            string tempNome = nomes[i]; 
                            nomes[i] = nomes[j];       
                            nomes[j] = tempNome;       
                        }
                    }
                }

               
                dataGridView1.Columns.Clear();        
                dataGridView1.Rows.Clear();           
                dataGridView1.ReadOnly = true;        
                dataGridView1.AllowUserToAddRows = false; 
                dataGridView1.RowHeadersVisible = false;  
                dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect; 
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; 

              
                dataGridView1.Columns.Add("Posicao", "Posição"); 
                dataGridView1.Columns.Add("Nome", "Nome");       
                dataGridView1.Columns.Add("Pontos", "Pontos");   

                
                for (int i = 0; i < contador; i++)               
                {
                    dataGridView1.Rows.Add((i + 1).ToString() + "º", nomes[i], pontos[i]); 
                    
                }
            }
            catch (Exception ex)                                  // Captura qualquer exceção ocorrida no bloco try.
            {
                MessageBox.Show("Erro ao carregar o arquivo: " + ex.Message); 
            }
               
		}
	}
}
