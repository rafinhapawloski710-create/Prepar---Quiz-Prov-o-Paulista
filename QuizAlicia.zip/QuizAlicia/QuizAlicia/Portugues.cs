﻿/*
 * Created by SharpDevelop.
 * User: rafin
 * Date: 08/10/2025
 * Time: 10:29
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace QuizAlicia
{
	/// <summary>
	/// Description of Portugues.
	/// </summary>
	public partial class Portugues : Form
	{
		public Portugues()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		string alternativaCorreta = "X";
		int pontos = 0;
		
		void BtnVoltarClick(object sender, EventArgs e)
		{
			Seleção telaSelecao = new Seleção();
			telaSelecao.Show();
			this.Hide();
		}
		
		void LblPortuguesClick(object sender, EventArgs e)
		{
			
		}
		
		void PortuguesLoad(object sender, EventArgs e)
		{
			
		}
		
		void Btn1Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "Qual é a função da vírgula na frase: “João, por favor, feche a janela”?";
			lblQA.Text = "Separar vocativo";
			lblQB.Text = "Indicar pausa de respiração";
			lblQC.Text = "Separar sujeito e predicado";
			lblQD.Text = "Indicar enumeração";
			alternativaCorreta = "A";
			
			pnlPergunta.Enabled = true;
			btn1.Enabled = false;
			btn2.Enabled = true;
		}
		
		void Btn2Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "Em “Eles chegaram cedo”, o verbo está no:";
			lblQA.Text = "Presente";
			lblQB.Text = "Passado (pretérito)";
			lblQC.Text = "Futuro";
			lblQD.Text = "Infinitivo";
			alternativaCorreta = "B";
			
			btn2.Enabled = false;
			pnlPergunta.Enabled = true;
			btn3.Enabled = true;
		}
		
		void Btn3Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "Qual das alternativas apresenta uma oração subordinada adjetiva?";
			lblQA.Text = "Quero que você venha.";
			lblQB.Text = "O livro que comprei é ótimo.";
			lblQC.Text = "Estudei porque tinha prova.";
			lblQD.Text = "Fui embora e não voltei.";
			alternativaCorreta = "B";
			
			btn3.Enabled = false;
			pnlPergunta.Enabled = true;
			btn4.Enabled = true;
		}
		
		void Btn4Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "O que é uma metáfora?";
			lblQA.Text = "Comparação direta";
			lblQB.Text = "Comparação implícita";
			lblQC.Text = "Repetição de palavras";
			lblQD.Text = "Exagero";
			alternativaCorreta = "B";
			
			btn4.Enabled = false;
			pnlPergunta.Enabled = true;
			btn5.Enabled = true;
		}
		
		void Btn5Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "Em “Corri tanto que fiquei cansado”, o termo “que” indica:";
			lblQA.Text = "Causa";
			lblQB.Text = "Consequência";
			lblQC.Text = "Condição";
			lblQD.Text = "Comparação";
			alternativaCorreta = "B";
			
			pnlPergunta.Enabled = true;
			btn5.Enabled = false;
			btnVerP.Enabled = true;
		}
		
		void BtnResetarClick(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = false;
			btn1.Enabled = true;
			btn2.Enabled = false;
			btn3.Enabled = false;
			btn4.Enabled = false;
			btn5.Enabled = false;
			lblTitulo.Text = "?";
			lblQA.Text = "?";
			lblQB.Text = "?";
			lblQC.Text = "?";
			lblQD.Text = "?";
			
			pontos = 0;
			
		}
		
		void BtnAClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "A"){
				MessageBox.Show("Você Acertou!");
				pontos++;
				
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void BtnBClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "B"){
				MessageBox.Show("Você Acertou!");
				pontos++;
				
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void BtnCClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "B"){
				MessageBox.Show("Você Acertou!");
				pontos++;
				
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void BtnDClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "D"){
				MessageBox.Show("Você Acertou!");
				pontos++;
				
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void BtnVerPClick(object sender, EventArgs e)
		{
			MessageBox.Show("Parabéns! Você completou o quiz. " + "Pontuação: " + pontos + "/5");
		}
	}
}
