﻿/*
 * Created by SharpDevelop.
 * User: rafin
 * Date: 24/11/2025
 * Time: 09:37
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace QuizAlicia
{
	/// <summary>
	/// Description of Parabens.
	/// </summary>
	public partial class Parabens : Form
	{
		int pontos;
		public Parabens(int p)
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			pontos=p;
			label3.Text = pontos + "/12";

			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		string arquivo = "pontuacoes.txt";
		
		void LblPontosClick(object sender, EventArgs e)
		{
			
		}
		
		void Label1Click(object sender, EventArgs e)
		{
			
		}
		
		void ParabensLoad(object sender, EventArgs e)
		{
			
		}
		
		void Label2Click(object sender, EventArgs e)
		{
			
		}
		
		void Label4Click(object sender, EventArgs e)
		{
			
		}
		
		void Label3Click(object sender, EventArgs e)
		{
			label3.Text = pontos + "/12";
		}
		
		void BtnVoltarClick(object sender, EventArgs e)
		{
			Seleção telaSelecao = new Seleção();
			telaSelecao.Show();
			this.Hide();			
		}
		
		void BtnSalvarClick(object sender, EventArgs e)
		{
			string nome = txtNome.Text.Trim();
			
			if (nome == ""){
        MessageBox.Show("Preencha com o seu nome.");
      } else {
        
        
          using (StreamWriter sw = File.AppendText(arquivo)){
            sw.WriteLine(nome + "," + pontos);
          }
          MessageBox.Show("Pontuação registrada com sucesso!");
                
      }

      txtNome.Clear();
      
    }
	}
}
