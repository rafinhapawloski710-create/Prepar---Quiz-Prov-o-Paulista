﻿/*
 * Created by SharpDevelop.
 * User: rafin
 * Date: 06/10/2025
 * Time: 11:12
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace QuizAlicia
{
	/// <summary>
	/// Description of Cadastro.
	/// </summary>
	public partial class Cadastro : Form
	{
		public Cadastro()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		
		 string arquivo = "usuarios.txt";
		void BtnEnviarClick(object sender, EventArgs e)
		{
			string usuario = txtNome.Text.Trim();
      string senha = txtSenha.Text.Trim();

      if (usuario == "" || senha == ""){
        MessageBox.Show("Preencha o usuário e a senha.");
        txtNome.Clear();
        txtSenha.Clear();
        return;
      } else {
        bool cadastrado = false;
        if (File.Exists(arquivo)){
            foreach (string linha in File.ReadAllLines(arquivo)) {
              string[] dados = linha.Split(';');
              if (dados[0] == usuario){
                MessageBox.Show("Usuário já cadastrado.");
                cadastrado = true;
              }
            }
        }

        if (cadastrado == false){
          using (StreamWriter sw = File.AppendText(arquivo)){
            sw.WriteLine(usuario + ";" + senha);
            cadastrado = true;
          }
          MessageBox.Show("Cadastro realizado com sucesso!");
        }          
      }

      txtNome.Clear();
      txtSenha.Clear();
      
			Inicio telaInicio = new Inicio();
			telaInicio.Show();
			this.Hide();
		}
		
		void BtnReiniciarClick(object sender, EventArgs e)
		{
			txtNome.Text = "";
			txtSenha.Text = "";
		}
		
		void BtnLoginClick(object sender, EventArgs e)
		{
			Login telaLogin = new Login();
			telaLogin.Show();
			this.Hide();
		}
		
		
		void LblJaPossuiClick(object sender, EventArgs e)
		{
			
		}
	}
}
