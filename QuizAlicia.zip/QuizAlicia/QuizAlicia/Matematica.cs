﻿/*
 * Created by SharpDevelop.
 * User: rafin
 * Date: 08/10/2025
 * Time: 10:30
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace QuizAlicia
{
	/// <summary>
	/// Description of Matematica.
	/// </summary>
	public partial class Matematica : Form
	{
		public Matematica()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		string alternativaCorreta = "X";
		int pontos = 0;
		
		void BtnVoltarClick(object sender, EventArgs e)
		{
			Seleção telaSelecao = new Seleção();
			telaSelecao.Show();
			this.Hide();
		}
		
		void BtnResetarClick(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = false;
			btn1.Enabled = true;
			btn2.Enabled = false;
			btn3.Enabled = false;
			btn4.Enabled = false;
			btn5.Enabled = false;
			lblTitulo.Text = "?";
			lblQA.Text = "?";
			lblQB.Text = "?";
			lblQC.Text = "?";
			lblQD.Text = "?";
			
			pontos = 0;
		}
		
		void BtnAClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "A"){
				MessageBox.Show("Você Acertou!");
				pontos++;
			} else {
				MessageBox.Show("Você Errou.");
				
			}
			pnlPergunta.Enabled = false;
		}
		
		void BtnBClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "A"){
				MessageBox.Show("Você Acertou!");
				pontos++;
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void BtnCClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "A"){
				MessageBox.Show("Você Acertou!");
				pontos++;
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void BtnDClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "A"){
				MessageBox.Show("Você Acertou!");
				pontos++;
			} else {
				MessageBox.Show("Você Errou.");
			}
			pnlPergunta.Enabled = false;
		}
		
		void Btn1Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "Qual é o valor de 2x + 4 = 10?";
			lblQA.Text = "2";
			lblQB.Text = "3";
			lblQC.Text = "4";
			lblQD.Text = "5";
			alternativaCorreta = "A";
			
			btn1.Enabled = false;
			pnlPergunta.Enabled = true;
			btn2.Enabled = true;
		}
		
		void Btn2Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "Raiz quadrada de 49 é:";
			lblQA.Text = "6";
			lblQB.Text = "7";
			lblQC.Text = "8";
			lblQD.Text = "9";
			alternativaCorreta = "";
			
			btn2.Enabled = false;
			pnlPergunta.Enabled = true;
			btn3.Enabled = true;
		}
		
		void Btn3Click(object sender, EventArgs e)
		{
			
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "Em um triângulo, a soma dos ângulos internos é sempre:";
			lblQA.Text = "90°";
			lblQB.Text = "120°";
			lblQC.Text = "180°";
			lblQD.Text = "360°";
			alternativaCorreta = "";
			
			btn3.Enabled = false;
			pnlPergunta.Enabled = true;
			btn4.Enabled = true;
		}
		
		void Btn4Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "O número 0,75 é igual a:";
			lblQA.Text = "3/4";
			lblQB.Text = "1/3";
			lblQC.Text = "1/4";
			lblQD.Text = "4/3";
			alternativaCorreta = "";
			
			btn4.Enabled = false;
			pnlPergunta.Enabled = true;
			btn5.Enabled = true;
		}
		
		void Btn5Click(object sender, EventArgs e)
		{
			pnlPergunta.Enabled = true;
			lblTitulo.Text = "Qual é o perímetro de um quadrado de lado 5 cm?";
			lblQA.Text = "10 cm";
			lblQB.Text = "15 cm";
			lblQC.Text = "20 cm";
			lblQD.Text = "25 cm";
			alternativaCorreta = "";
			
			btn5.Enabled = false;
			pnlPergunta.Enabled = true;
			btnVerP.Enabled = true;
		}
		
		void LblAcertosClick(object sender, EventArgs e)
		{
			
		}
		
		void Panel1Paint(object sender, PaintEventArgs e)
		{
			
		}
		
		void BtnVerPClick(object sender, EventArgs e)
		{
			MessageBox.Show("Parabéns! Você completou o quiz. " + "Pontuação: " + pontos + "/5");
		}
	}
}
