﻿/*
 * Created by SharpDevelop.
 * User: rafin
 * Date: 08/10/2025
 * Time: 10:30
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace QuizAlicia
{
	partial class Geral
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnVoltar = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.btn12 = new System.Windows.Forms.Button();
			this.btn6 = new System.Windows.Forms.Button();
			this.btn11 = new System.Windows.Forms.Button();
			this.lblGeral = new System.Windows.Forms.Label();
			this.btn10 = new System.Windows.Forms.Button();
			this.pnlPergunta = new System.Windows.Forms.Panel();
			this.btnD = new System.Windows.Forms.Button();
			this.btnC = new System.Windows.Forms.Button();
			this.btnB = new System.Windows.Forms.Button();
			this.btnA = new System.Windows.Forms.Button();
			this.lblQD = new System.Windows.Forms.Label();
			this.lblQC = new System.Windows.Forms.Label();
			this.lblQB = new System.Windows.Forms.Label();
			this.lblQA = new System.Windows.Forms.Label();
			this.lblTitulo = new System.Windows.Forms.Label();
			this.btn7 = new System.Windows.Forms.Button();
			this.btnResetar = new System.Windows.Forms.Button();
			this.btn9 = new System.Windows.Forms.Button();
			this.btn8 = new System.Windows.Forms.Button();
			this.btn5 = new System.Windows.Forms.Button();
			this.btn4 = new System.Windows.Forms.Button();
			this.btn1 = new System.Windows.Forms.Button();
			this.btn3 = new System.Windows.Forms.Button();
			this.btn2 = new System.Windows.Forms.Button();
			this.btnVerP = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			this.pnlPergunta.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnVoltar
			// 
			this.btnVoltar.BackColor = System.Drawing.Color.DarkSeaGreen;
			this.btnVoltar.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnVoltar.Location = new System.Drawing.Point(82, 386);
			this.btnVoltar.Name = "btnVoltar";
			this.btnVoltar.Size = new System.Drawing.Size(78, 35);
			this.btnVoltar.TabIndex = 6;
			this.btnVoltar.Text = "<----";
			this.btnVoltar.UseVisualStyleBackColor = false;
			this.btnVoltar.Click += new System.EventHandler(this.BtnVoltarClick);
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.PaleGreen;
			this.panel1.Controls.Add(this.btn12);
			this.panel1.Controls.Add(this.btn6);
			this.panel1.Controls.Add(this.btn11);
			this.panel1.Controls.Add(this.lblGeral);
			this.panel1.Controls.Add(this.btn10);
			this.panel1.Controls.Add(this.pnlPergunta);
			this.panel1.Controls.Add(this.btn7);
			this.panel1.Controls.Add(this.btnResetar);
			this.panel1.Controls.Add(this.btn9);
			this.panel1.Controls.Add(this.btn8);
			this.panel1.Controls.Add(this.btn5);
			this.panel1.Controls.Add(this.btn4);
			this.panel1.Controls.Add(this.btn1);
			this.panel1.Controls.Add(this.btn3);
			this.panel1.Controls.Add(this.btn2);
			this.panel1.Location = new System.Drawing.Point(39, 34);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(415, 341);
			this.panel1.TabIndex = 8;
			this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel1Paint);
			// 
			// btn12
			// 
			this.btn12.Enabled = false;
			this.btn12.Location = new System.Drawing.Point(237, 287);
			this.btn12.Name = "btn12";
			this.btn12.Size = new System.Drawing.Size(38, 23);
			this.btn12.TabIndex = 13;
			this.btn12.Text = "12";
			this.btn12.UseVisualStyleBackColor = true;
			this.btn12.Click += new System.EventHandler(this.Btn12Click);
			// 
			// btn6
			// 
			this.btn6.Enabled = false;
			this.btn6.Location = new System.Drawing.Point(237, 258);
			this.btn6.Name = "btn6";
			this.btn6.Size = new System.Drawing.Size(38, 23);
			this.btn6.TabIndex = 13;
			this.btn6.Text = "6";
			this.btn6.UseVisualStyleBackColor = true;
			this.btn6.Click += new System.EventHandler(this.Btn6Click);
			// 
			// btn11
			// 
			this.btn11.Enabled = false;
			this.btn11.Location = new System.Drawing.Point(200, 287);
			this.btn11.Name = "btn11";
			this.btn11.Size = new System.Drawing.Size(38, 23);
			this.btn11.TabIndex = 17;
			this.btn11.Text = "11";
			this.btn11.UseVisualStyleBackColor = true;
			this.btn11.Click += new System.EventHandler(this.Btn11Click);
			// 
			// lblGeral
			// 
			this.lblGeral.Font = new System.Drawing.Font("Script MT Bold", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblGeral.Location = new System.Drawing.Point(118, 10);
			this.lblGeral.Name = "lblGeral";
			this.lblGeral.Size = new System.Drawing.Size(208, 48);
			this.lblGeral.TabIndex = 15;
			this.lblGeral.Text = "Quiz Geral";
			// 
			// btn10
			// 
			this.btn10.Enabled = false;
			this.btn10.Location = new System.Drawing.Point(163, 287);
			this.btn10.Name = "btn10";
			this.btn10.Size = new System.Drawing.Size(38, 23);
			this.btn10.TabIndex = 16;
			this.btn10.Text = "10";
			this.btn10.UseVisualStyleBackColor = true;
			this.btn10.Click += new System.EventHandler(this.Btn10Click);
			// 
			// pnlPergunta
			// 
			this.pnlPergunta.BackColor = System.Drawing.Color.White;
			this.pnlPergunta.Controls.Add(this.btnD);
			this.pnlPergunta.Controls.Add(this.btnC);
			this.pnlPergunta.Controls.Add(this.btnB);
			this.pnlPergunta.Controls.Add(this.btnA);
			this.pnlPergunta.Controls.Add(this.lblQD);
			this.pnlPergunta.Controls.Add(this.lblQC);
			this.pnlPergunta.Controls.Add(this.lblQB);
			this.pnlPergunta.Controls.Add(this.lblQA);
			this.pnlPergunta.Controls.Add(this.lblTitulo);
			this.pnlPergunta.Location = new System.Drawing.Point(39, 63);
			this.pnlPergunta.Name = "pnlPergunta";
			this.pnlPergunta.Size = new System.Drawing.Size(330, 180);
			this.pnlPergunta.TabIndex = 14;
			// 
			// btnD
			// 
			this.btnD.Enabled = false;
			this.btnD.Location = new System.Drawing.Point(6, 143);
			this.btnD.Name = "btnD";
			this.btnD.Size = new System.Drawing.Size(25, 27);
			this.btnD.TabIndex = 18;
			this.btnD.Text = "D";
			this.btnD.UseVisualStyleBackColor = true;
			this.btnD.Click += new System.EventHandler(this.BtnDClick);
			// 
			// btnC
			// 
			this.btnC.Enabled = false;
			this.btnC.Location = new System.Drawing.Point(6, 111);
			this.btnC.Name = "btnC";
			this.btnC.Size = new System.Drawing.Size(25, 27);
			this.btnC.TabIndex = 17;
			this.btnC.Text = "C";
			this.btnC.UseVisualStyleBackColor = true;
			this.btnC.Click += new System.EventHandler(this.BtnCClick);
			// 
			// btnB
			// 
			this.btnB.Enabled = false;
			this.btnB.Location = new System.Drawing.Point(6, 79);
			this.btnB.Name = "btnB";
			this.btnB.Size = new System.Drawing.Size(25, 27);
			this.btnB.TabIndex = 16;
			this.btnB.Text = "B";
			this.btnB.UseVisualStyleBackColor = true;
			this.btnB.Click += new System.EventHandler(this.BtnBClick);
			// 
			// btnA
			// 
			this.btnA.Enabled = false;
			this.btnA.Location = new System.Drawing.Point(6, 46);
			this.btnA.Name = "btnA";
			this.btnA.Size = new System.Drawing.Size(25, 27);
			this.btnA.TabIndex = 15;
			this.btnA.Text = "A";
			this.btnA.UseVisualStyleBackColor = true;
			this.btnA.Click += new System.EventHandler(this.BtnAClick);
			// 
			// lblQD
			// 
			this.lblQD.Location = new System.Drawing.Point(37, 148);
			this.lblQD.Name = "lblQD";
			this.lblQD.Size = new System.Drawing.Size(277, 23);
			this.lblQD.TabIndex = 8;
			this.lblQD.Text = "?";
			// 
			// lblQC
			// 
			this.lblQC.Location = new System.Drawing.Point(37, 116);
			this.lblQC.Name = "lblQC";
			this.lblQC.Size = new System.Drawing.Size(277, 23);
			this.lblQC.TabIndex = 7;
			this.lblQC.Text = "?";
			// 
			// lblQB
			// 
			this.lblQB.Location = new System.Drawing.Point(37, 84);
			this.lblQB.Name = "lblQB";
			this.lblQB.Size = new System.Drawing.Size(277, 23);
			this.lblQB.TabIndex = 6;
			this.lblQB.Text = "?";
			// 
			// lblQA
			// 
			this.lblQA.Location = new System.Drawing.Point(37, 51);
			this.lblQA.Name = "lblQA";
			this.lblQA.Size = new System.Drawing.Size(277, 23);
			this.lblQA.TabIndex = 5;
			this.lblQA.Text = "?";
			// 
			// lblTitulo
			// 
			this.lblTitulo.Location = new System.Drawing.Point(3, 10);
			this.lblTitulo.Name = "lblTitulo";
			this.lblTitulo.Size = new System.Drawing.Size(296, 41);
			this.lblTitulo.TabIndex = 0;
			this.lblTitulo.Text = "?";
			// 
			// btn7
			// 
			this.btn7.Enabled = false;
			this.btn7.Location = new System.Drawing.Point(52, 287);
			this.btn7.Name = "btn7";
			this.btn7.Size = new System.Drawing.Size(38, 23);
			this.btn7.TabIndex = 13;
			this.btn7.Text = "7";
			this.btn7.UseVisualStyleBackColor = true;
			this.btn7.Click += new System.EventHandler(this.Btn7Click);
			// 
			// btnResetar
			// 
			this.btnResetar.BackColor = System.Drawing.Color.DarkSeaGreen;
			this.btnResetar.Location = new System.Drawing.Point(299, 267);
			this.btnResetar.Name = "btnResetar";
			this.btnResetar.Size = new System.Drawing.Size(88, 36);
			this.btnResetar.TabIndex = 13;
			this.btnResetar.Text = "Resetar";
			this.btnResetar.UseVisualStyleBackColor = false;
			this.btnResetar.Click += new System.EventHandler(this.BtnResetarClick);
			// 
			// btn9
			// 
			this.btn9.Enabled = false;
			this.btn9.Location = new System.Drawing.Point(126, 287);
			this.btn9.Name = "btn9";
			this.btn9.Size = new System.Drawing.Size(38, 23);
			this.btn9.TabIndex = 15;
			this.btn9.Text = "9";
			this.btn9.UseVisualStyleBackColor = true;
			this.btn9.Click += new System.EventHandler(this.Btn9Click);
			// 
			// btn8
			// 
			this.btn8.Enabled = false;
			this.btn8.Location = new System.Drawing.Point(89, 287);
			this.btn8.Name = "btn8";
			this.btn8.Size = new System.Drawing.Size(38, 23);
			this.btn8.TabIndex = 14;
			this.btn8.Text = "8";
			this.btn8.UseVisualStyleBackColor = true;
			this.btn8.Click += new System.EventHandler(this.Btn8Click);
			// 
			// btn5
			// 
			this.btn5.Enabled = false;
			this.btn5.Location = new System.Drawing.Point(200, 258);
			this.btn5.Name = "btn5";
			this.btn5.Size = new System.Drawing.Size(38, 23);
			this.btn5.TabIndex = 12;
			this.btn5.Text = "5";
			this.btn5.UseVisualStyleBackColor = true;
			this.btn5.Click += new System.EventHandler(this.Btn5Click);
			// 
			// btn4
			// 
			this.btn4.Enabled = false;
			this.btn4.Location = new System.Drawing.Point(163, 258);
			this.btn4.Name = "btn4";
			this.btn4.Size = new System.Drawing.Size(38, 23);
			this.btn4.TabIndex = 11;
			this.btn4.Text = "4";
			this.btn4.UseVisualStyleBackColor = true;
			this.btn4.Click += new System.EventHandler(this.Btn4Click);
			// 
			// btn1
			// 
			this.btn1.Location = new System.Drawing.Point(52, 258);
			this.btn1.Name = "btn1";
			this.btn1.Size = new System.Drawing.Size(38, 23);
			this.btn1.TabIndex = 8;
			this.btn1.Text = "1";
			this.btn1.UseVisualStyleBackColor = true;
			this.btn1.Click += new System.EventHandler(this.Btn1Click);
			// 
			// btn3
			// 
			this.btn3.Enabled = false;
			this.btn3.Location = new System.Drawing.Point(126, 258);
			this.btn3.Name = "btn3";
			this.btn3.Size = new System.Drawing.Size(38, 23);
			this.btn3.TabIndex = 10;
			this.btn3.Text = "3";
			this.btn3.UseVisualStyleBackColor = true;
			this.btn3.Click += new System.EventHandler(this.Btn3Click);
			// 
			// btn2
			// 
			this.btn2.Enabled = false;
			this.btn2.Location = new System.Drawing.Point(89, 258);
			this.btn2.Name = "btn2";
			this.btn2.Size = new System.Drawing.Size(38, 23);
			this.btn2.TabIndex = 9;
			this.btn2.Text = "2";
			this.btn2.UseVisualStyleBackColor = true;
			this.btn2.Click += new System.EventHandler(this.Btn2Click);
			// 
			// btnVerP
			// 
			this.btnVerP.BackColor = System.Drawing.Color.DarkSeaGreen;
			this.btnVerP.Enabled = false;
			this.btnVerP.Location = new System.Drawing.Point(303, 386);
			this.btnVerP.Name = "btnVerP";
			this.btnVerP.Size = new System.Drawing.Size(120, 35);
			this.btnVerP.TabIndex = 10;
			this.btnVerP.Text = "Ver Pontuação";
			this.btnVerP.UseVisualStyleBackColor = false;
			this.btnVerP.Click += new System.EventHandler(this.Button1Click);
			// 
			// Geral
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(486, 433);
			this.Controls.Add(this.btnVerP);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.btnVoltar);
			this.Name = "Geral";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Geral";
			this.panel1.ResumeLayout(false);
			this.pnlPergunta.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Button btnVerP;
		private System.Windows.Forms.Button btn6;
		private System.Windows.Forms.Button btn12;
		private System.Windows.Forms.Button btn8;
		private System.Windows.Forms.Button btn9;
		private System.Windows.Forms.Button btn7;
		private System.Windows.Forms.Button btn10;
		private System.Windows.Forms.Button btn11;
		private System.Windows.Forms.Button btnD;
		private System.Windows.Forms.Button btnC;
		private System.Windows.Forms.Button btnB;
		private System.Windows.Forms.Button btnA;
		private System.Windows.Forms.Button btn2;
		private System.Windows.Forms.Button btn3;
		private System.Windows.Forms.Button btn1;
		private System.Windows.Forms.Button btn4;
		private System.Windows.Forms.Button btn5;
		private System.Windows.Forms.Button btnResetar;
		private System.Windows.Forms.Label lblTitulo;
		private System.Windows.Forms.Label lblQA;
		private System.Windows.Forms.Label lblQB;
		private System.Windows.Forms.Label lblQC;
		private System.Windows.Forms.Label lblQD;
		private System.Windows.Forms.Panel pnlPergunta;
		private System.Windows.Forms.Label lblGeral;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button btnVoltar;
	}
}
