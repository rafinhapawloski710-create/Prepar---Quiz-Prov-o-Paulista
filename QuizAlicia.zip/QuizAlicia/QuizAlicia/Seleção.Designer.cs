﻿/*
 * Created by SharpDevelop.
 * User: rafin
 * Date: 08/10/2025
 * Time: 09:16
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace QuizAlicia
{
	partial class Seleção
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Seleção));
			this.lblSeleção = new System.Windows.Forms.Label();
			this.lblHumanas = new System.Windows.Forms.Label();
			this.lblExatas = new System.Windows.Forms.Label();
			this.btnVoltar = new System.Windows.Forms.Button();
			this.btnPort = new System.Windows.Forms.Button();
			this.btnHist = new System.Windows.Forms.Button();
			this.btnGeo = new System.Windows.Forms.Button();
			this.btnQui = new System.Windows.Forms.Button();
			this.btnFis = new System.Windows.Forms.Button();
			this.btnMat = new System.Windows.Forms.Button();
			this.btnGeral = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// lblSeleção
			// 
			this.lblSeleção.Font = new System.Drawing.Font("Script MT Bold", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblSeleção.Location = new System.Drawing.Point(102, 108);
			this.lblSeleção.Name = "lblSeleção";
			this.lblSeleção.Size = new System.Drawing.Size(287, 53);
			this.lblSeleção.TabIndex = 0;
			this.lblSeleção.Text = "Seleção de Jogo";
			this.lblSeleção.Click += new System.EventHandler(this.LblSeleçãoClick);
			// 
			// lblHumanas
			// 
			this.lblHumanas.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblHumanas.Location = new System.Drawing.Point(114, 173);
			this.lblHumanas.Name = "lblHumanas";
			this.lblHumanas.Size = new System.Drawing.Size(104, 23);
			this.lblHumanas.TabIndex = 1;
			this.lblHumanas.Text = "Humanas:";
			this.lblHumanas.Click += new System.EventHandler(this.LblHumanasClick);
			// 
			// lblExatas
			// 
			this.lblExatas.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblExatas.Location = new System.Drawing.Point(274, 173);
			this.lblExatas.Name = "lblExatas";
			this.lblExatas.Size = new System.Drawing.Size(100, 23);
			this.lblExatas.TabIndex = 2;
			this.lblExatas.Text = "Exatas:";
			// 
			// btnVoltar
			// 
			this.btnVoltar.BackColor = System.Drawing.Color.DarkSeaGreen;
			this.btnVoltar.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnVoltar.Location = new System.Drawing.Point(59, 351);
			this.btnVoltar.Name = "btnVoltar";
			this.btnVoltar.Size = new System.Drawing.Size(78, 35);
			this.btnVoltar.TabIndex = 5;
			this.btnVoltar.Text = "<----";
			this.btnVoltar.UseVisualStyleBackColor = false;
			this.btnVoltar.Click += new System.EventHandler(this.BtnVoltarClick);
			// 
			// btnPort
			// 
			this.btnPort.Location = new System.Drawing.Point(102, 213);
			this.btnPort.Name = "btnPort";
			this.btnPort.Size = new System.Drawing.Size(104, 27);
			this.btnPort.TabIndex = 6;
			this.btnPort.Text = "Português";
			this.btnPort.UseVisualStyleBackColor = true;
			this.btnPort.Click += new System.EventHandler(this.Button1Click);
			// 
			// btnHist
			// 
			this.btnHist.Location = new System.Drawing.Point(102, 255);
			this.btnHist.Name = "btnHist";
			this.btnHist.Size = new System.Drawing.Size(104, 27);
			this.btnHist.TabIndex = 7;
			this.btnHist.Text = "História";
			this.btnHist.UseVisualStyleBackColor = true;
			this.btnHist.Click += new System.EventHandler(this.Button2Click);
			// 
			// btnGeo
			// 
			this.btnGeo.Location = new System.Drawing.Point(102, 299);
			this.btnGeo.Name = "btnGeo";
			this.btnGeo.Size = new System.Drawing.Size(104, 27);
			this.btnGeo.TabIndex = 8;
			this.btnGeo.Text = "Geografia";
			this.btnGeo.UseVisualStyleBackColor = true;
			this.btnGeo.Click += new System.EventHandler(this.Button3Click);
			// 
			// btnQui
			// 
			this.btnQui.Location = new System.Drawing.Point(258, 213);
			this.btnQui.Name = "btnQui";
			this.btnQui.Size = new System.Drawing.Size(104, 27);
			this.btnQui.TabIndex = 9;
			this.btnQui.Text = "Química";
			this.btnQui.UseVisualStyleBackColor = true;
			this.btnQui.Click += new System.EventHandler(this.Button4Click);
			// 
			// btnFis
			// 
			this.btnFis.Location = new System.Drawing.Point(258, 255);
			this.btnFis.Name = "btnFis";
			this.btnFis.Size = new System.Drawing.Size(104, 27);
			this.btnFis.TabIndex = 10;
			this.btnFis.Text = "Física";
			this.btnFis.UseVisualStyleBackColor = true;
			this.btnFis.Click += new System.EventHandler(this.Button5Click);
			// 
			// btnMat
			// 
			this.btnMat.Location = new System.Drawing.Point(258, 299);
			this.btnMat.Name = "btnMat";
			this.btnMat.Size = new System.Drawing.Size(104, 27);
			this.btnMat.TabIndex = 11;
			this.btnMat.Text = "Matemática";
			this.btnMat.UseVisualStyleBackColor = true;
			this.btnMat.Click += new System.EventHandler(this.Button6Click);
			// 
			// btnGeral
			// 
			this.btnGeral.Location = new System.Drawing.Point(192, 351);
			this.btnGeral.Name = "btnGeral";
			this.btnGeral.Size = new System.Drawing.Size(104, 27);
			this.btnGeral.TabIndex = 12;
			this.btnGeral.Text = "Quiz Geral";
			this.btnGeral.UseVisualStyleBackColor = true;
			this.btnGeral.Click += new System.EventHandler(this.Button7Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(192, 19);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(81, 75);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 13;
			this.pictureBox1.TabStop = false;
			// 
			// Seleção
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(464, 423);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.btnGeral);
			this.Controls.Add(this.btnMat);
			this.Controls.Add(this.btnFis);
			this.Controls.Add(this.btnQui);
			this.Controls.Add(this.btnGeo);
			this.Controls.Add(this.btnHist);
			this.Controls.Add(this.btnPort);
			this.Controls.Add(this.btnVoltar);
			this.Controls.Add(this.lblExatas);
			this.Controls.Add(this.lblHumanas);
			this.Controls.Add(this.lblSeleção);
			this.Name = "Seleção";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Seleção";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button btnGeral;
		private System.Windows.Forms.Button btnMat;
		private System.Windows.Forms.Button btnFis;
		private System.Windows.Forms.Button btnQui;
		private System.Windows.Forms.Button btnGeo;
		private System.Windows.Forms.Button btnHist;
		private System.Windows.Forms.Button btnPort;
		private System.Windows.Forms.Button btnVoltar;
		private System.Windows.Forms.Label lblExatas;
		private System.Windows.Forms.Label lblHumanas;
		private System.Windows.Forms.Label lblSeleção;
	}
}
